# Engenharia de Software 2 - AC2

Esse é o repositório que irá conter as entregas da AC1 de Engenharia de Software 2.

## Como rodar

> É necessário que você possua o NodeJS 18.x para rodar esse projeto.

Para rodar os testes, clone esse repositório e depois instale as dependências:

```bash
npm ci
```

E depois, basta rodar os testes com o comando:

```bash
npm run test
```
